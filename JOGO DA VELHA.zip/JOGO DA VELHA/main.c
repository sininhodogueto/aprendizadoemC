#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/*
Título: "Jogo da velha"
Autor: "Gabriel Gonçalves Freitas"
Turma: CIÊNCIA DA COMPUTAÇÃO - 2º SEMESTRE

|
|
|
|
|
|
|
*/

int main(void){

    setlocale(LC_ALL, "Portuguese");

    char opcao;

    mensagem_inicial();

    scanf("%c%*c", &opcao);

    while(opcao != 's' && opcao != 'S' && opcao != 'n' && opcao != 'N'){

        system("clear");
        mensagem_inicial_errada();
        scanf("%c%*c", &opcao);

    }

    if(opcao == 's' || opcao == 'S'){

        system("clear");
        jogo();

    }

    else{

        system("clear");
        printf("\n\nJogo encerrado.\n\n");

    }
}


int jogo(void){

    char m[3][3];
    m[0][0] = ' ';
    m[0][1] = ' ';
    m[0][2] = ' ';
    m[1][0] = ' ';
    m[1][1] = ' ';
    m[1][2] = ' ';
    m[2][0] = ' ';
    m[2][1] = ' ';
    m[2][2] = ' ';
    char jogX, jogO;
    char vencedor[9] = "VAZIO";
    char vencauxi;
    int turno = 1, lin, col;

    printf("\n\t\t       1 para [Jogador 1]\n\t\t       2 para [Jogador 2]");
    printf("\n\nQuem vai jogar com \"X\"?: ");
    scanf("%c%*c", &jogX);

    while(jogX != '1' && jogX != '2'){

        system("clear");
        printf("\t\t-------------------------------");
        printf("\n\t\tOpção errada. Insira novamente!");
        printf("\n\t\t-------------------------------");
        printf("\n\n\t\t       1 para [Jogador 1]\n\t\t       2 para [Jogador 2]");
        printf("\n\nQuem vai jogar com \"X\"?: ");
        scanf("%c%*c", &jogX);

    }

    if(jogX == '1') jogO = '2';
    else if (jogX == '2') jogO = '1';

    system("clear");

    while(turno < 10){

        if(turno%2 != 0) {
            system("clear");

            tabuleiro(m);

            printf("Turno %d\n\n", turno);
            printf("Vez do jogador %c (X)\n\n", jogX);

            printf("\nInsira a linha: ");
            scanf("%d%*c", &lin);

            printf("Insira a coluna: ");
            scanf("%d%*c", &col);

            lin -= 1;
            col -= 1;

            while(m[lin][col] != ' '){
                system("clear");

                tabuleiro(m);

                printf("Posição já preenchida. Insira novamente!\n\n");

                printf("Turno %d\n\n", turno);
                printf("Vez do jogador %c (X)\n\n", jogX);

                printf("\nInsira a linha: ");
                scanf("%d%*c", &lin);

                printf("Insira a coluna: ");
                scanf("%d%*c", &col);

                lin -= 1;
                col -= 1;
            }

            m[lin][col] = 'X';

        }

        else if(turno%2 == 0){
            system("clear");

            tabuleiro(m);

            printf("Turno %d\n\n", turno);
            printf("Vez do jogador %c (O)\n\n", jogO);

            printf("\nInsira a linha: ");
            scanf("%d%*c", &lin);

            printf("Insira a coluna: ");
            scanf("%d%*c", &col);

            lin -= 1;
            col -= 1;

            while(m[lin][col] != ' '){
                system("clear");

                tabuleiro(m);

                printf("Posição já preenchida. Insira novamente!\n\n");

                printf("Turno %d\n\n", turno);
                printf("Vez do jogador %c (O)\n\n", jogO);

                printf("\nInsira a linha: ");
                scanf("%d%*c", &lin);

                printf("Insira a coluna: ");
                scanf("%d%*c", &col);

                lin -= 1;
                col -= 1;
            }

            m[lin][col] = 'O';

        }

        system("clear");

        if(turno > 3){
            if(m[0][0] == m[1][1] && m[0][0] == m[2][2] && m[1][1] == m[2][2]){
                tabuleiro(m);
                if(m[0][0] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
            else if(m[0][2] == m[1][1] && m[0][2] == m[2][0] && m[1][1] == m[0][2]){
                tabuleiro(m);
                if(m[0][2] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
            else if(m[0][0] == m[0][1] && m[0][0] == m[0][2] && m[0][0] == m[0][2]){
                tabuleiro(m);
                if(m[0][0] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
            else if(m[1][0] == m[1][1] && m[1][0] == m[1][2] && m[1][1] == m[1][2]){
                tabuleiro(m);
                if(m[1][0] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
            else if(m[2][0] == m[2][1] && m[2][0] == m[2][2] && m[2][1] == m[2][2]){
                tabuleiro(m);
                if(m[2][0] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
            else if(m[0][0] == m[1][0] && m[0][0] == m[2][0] && m[1][0] == m[2][0]){
                tabuleiro(m);
                if(m[0][0] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
            else if(m[0][1] == m[1][1] && m[0][1] == m[2][1] && m[1][1] == m[2][1]){
                tabuleiro(m);
                if(m[0][1] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }

            else if(m[0][2] == m[1][2] && m[0][2] == m[2][2] && m[1][1] == m[2][2]){
                tabuleiro(m);
                if(m[0][2] == 'X') printf("\n\tO jogador %c foi o vencedor!\n\n", jogX);
                else printf("\n\t  O jogador %c vendeu!\n\n", jogO);
                turno = 11;
            }
        }

        turno++;

    }
}

int tabuleiro(char m[3][3]){
    printf("\t\t %c | %c | %c\n", m[0][0], m[0][1], m[0][2]);
    printf("\t\t-----------\n");
    printf("\t\t %c | %c | %c\n", m[1][0], m[1][1], m[1][2]);
    printf("\t\t-----------\n");
    printf("\t\t %c | %c | %c\n\n\n", m[2][0], m[2][1], m[2][2]);
}

void mensagem_inicial(void){

    setlocale(LC_ALL, "Portuguese");

    printf("\t\t      1, 1 | 1, 2 | 1, 3\n");
    printf("\t\t      ------------------\n");
    printf("\t\t      2, 1 | 2, 2 | 2, 3\n");
    printf("\t\t      ------------------\n");
    printf("\t\t      3, 1 | 3, 2 | 3, 3\n\n\n");
    printf("\tEste programa irá utilizar coordenadas \"x, y\"!\n\n");
    printf("\tPrimeiramente lhe será solicitado a linha e em\n\tseguida   a   coluna  para  inserir  a  figura!\n\n");
    printf("\nIniciar? s[SIM]/n[NÃO]: ");

}

void mensagem_inicial_errada(void){

    setlocale(LC_ALL, "Portuguese");

    printf("\t\t      1, 1 | 1, 2 | 1, 3\n");
    printf("\t\t      ------------------\n");
    printf("\t\t      2, 1 | 2, 2 | 2, 3\n");
    printf("\t\t      ------------------\n");
    printf("\t\t      3, 1 | 3, 2 | 3, 3\n\n\n");
    printf("\tEste programa irá utilizar coordenadas \"x, y\"!\n\n");
    printf("\tPrimeiramente lhe será solicitado a linha e em\n\tseguida   a   coluna para  inserir  a  figura!\n\n");
    printf("\n\t\t-------------------------------");
    printf("\n\t\tOpção errada. Insira novamente!");
    printf("\n\t\t-------------------------------");
    printf("\n\nIniciar? s[SIM]/n[NÃO]: ");

}
